# MultiLayer-Perceptron
Tugas Uas Kecerdasan Buatan
